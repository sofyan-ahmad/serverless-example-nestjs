
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'magishift',
  applicationName: 'techtalk',
  appUid: 'vdpb1cTbnWcgp12nKh',
  orgUid: '44kgGRpNpZRsJxDb8z',
  deploymentUid: '9e2d79dd-4d8e-44e2-a7b7-09a791ab8750',
  serviceName: 'serverless-nestjs',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'prod',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '3.6.12',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'serverless-nestjs-prod-index', timeout: 6 };

try {
  const userHandler = require('./_optimize/serverless-nestjs-prod-index/dist/index.js');
  module.exports.handler = serverlessSDK.handler(userHandler.handler, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}